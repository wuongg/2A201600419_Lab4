# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
Với temperature tăng từ thấp đến cao, câu trả lời thường trở nên đa dạng hơn về cách diễn đạt và độ “sáng tạo”, nhưng cũng dễ lệch khỏi mẫu nhất quán. Temperature thấp cho phản hồi gọn, lặp lại ý, thiên về dự đoán (ít biến thiên), trong khi temperature cao khiến phong cách câu chuyện/phản hồi ít ổn định hơn. Nói chung: càng cao thì độ ngẫu nhiên càng lớn.

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
Mình sẽ đặt temperature khoảng `0.2–0.5` (thường ưu tiên `~0.2–0.3`) để chatbot trả lời nhất quán, ít “bịa” và bám sát chính sách/FAQ. Với hỗ trợ khách hàng, độ chính xác và tính lặp lại quan trọng hơn sự sáng tạo, nên nhiệt độ càng thấp càng tốt trong giới hạn vẫn cho câu trả lời tự nhiên.

---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
Tổng token/ngày ≈ 10,000 × 3 × 350 = 10,500,000 token ≈ 10,500 “1K token”.

- GPT-4o: 10,500 × 0.010 ≈ 105 USD/ngày  
- GPT-4o-mini: 10,500 × 0.0006 ≈ 6.3 USD/ngày  

Tỉ lệ: 105 / 6.3 ≈ 16.67 ⇒ GPT-4o đắt hơn khoảng **16–17 lần** cho workload này.

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
Chi phí của GPT-4o đáng giá khi cần suy luận phức tạp, xử lý yêu cầu mơ hồ, hoặc tạo nội dung cần chất lượng/độ mạch lạc cao (ví dụ: phân tích khiếu nại dài, trả lời bằng nhiều ràng buộc chính sách, hoặc viết email phản hồi quan trọng cho khách VIP). Còn GPT-4o-mini phù hợp khi khối lượng lớn, yêu cầu đơn giản và cần độ trễ thấp/cost thấp (ví dụ: trả lời theo FAQ, trích xuất thông tin từ tin nhắn, phân loại yêu cầu, hoặc tóm tắt ngắn hàng loạt).

---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
Streaming quan trọng nhất khi người dùng phải chờ lâu và cần cảm giác “đang có tiến triển” (ví dụ: câu trả lời dài, giải thích nhiều bước, hoặc bot tạo nội dung theo thời gian thực). Nó cải thiện trải nghiệm vì người dùng thấy token xuất hiện ngay lập tức thay vì chờ phản hồi hoàn tất. Ngược lại, non-streaming phù hợp hơn khi output cần được xuất ra hoàn chỉnh trước khi dùng tiếp (ví dụ: cần parse JSON/XML, cần đánh giá độ đầy đủ theo cấu trúc, hoặc hiển thị theo “khung” hoàn chỉnh để tránh gây rối UI).


## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
